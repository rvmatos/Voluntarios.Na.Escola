﻿using Ninject.Modules;
using System;
using VoluntariosNaEscola.Domain.Interfaces.AppService;

namespace VoluntariosNaEscola.Infra.CrossCutting.InversionOfControl.Modules
{
    public class AppServiceModule : NinjectModule
    {
        public override void Load()
        {
           
        }
    }
}
